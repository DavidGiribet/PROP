package test;


public class SolucionadorKenkenTest {
}
