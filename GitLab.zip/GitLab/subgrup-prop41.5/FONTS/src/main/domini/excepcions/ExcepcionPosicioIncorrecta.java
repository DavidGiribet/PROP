package main.domini.excepcions;

public class ExcepcionPosicioIncorrecta extends Exception {
    private String missatge;

    public ExcepcionPosicioIncorrecta() {
        this("La posició es incorrecta");
    }

    public ExcepcionPosicioIncorrecta(String s) {
        super(s);
        this.missatge = s;
    }

    @Override
    public String toString() {
        return "Excepcio Regio: " + missatge;
    }
}
